/*
-- Query: 
-- Date: 2014-02-27 19:12
*/
INSERT INTO `CON_UnidadMonetaria` (`CON_UnidadMonetaria_ID`,`CON_UnidadMonetaria_Nombre`,`CON_UnidadMonetaria_Observacion`,`CON_UnidadMonetaria_TasaConversion`,`CON_UnidadMonetaria_FechaCreacion`,`CON_UnidadMonetaria_FechaModificacion`) VALUES (1,'Lempira','Moneda Local (Honduras)',1,Now(),Now());
INSERT INTO `CON_UnidadMonetaria` (`CON_UnidadMonetaria_ID`,`CON_UnidadMonetaria_Nombre`,`CON_UnidadMonetaria_Observacion`,`CON_UnidadMonetaria_TasaConversion`,`CON_UnidadMonetaria_FechaCreacion`,`CON_UnidadMonetaria_FechaModificacion`) VALUES (2,'Dolar','Moneda Norteamericana (Estados Unidos)',19.73,Now(),Now());
