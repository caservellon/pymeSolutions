/*
-- Query: 
-- Date: 2014-02-27 19:10
*/
INSERT INTO `CON_MotivoTransaccion` (`CON_MotivoTransaccion_ID`,`CON_MotivoTransaccion_Codigo`,`CON_MotivoTransaccion_Descripcion`,`CON_MotivoTransaccion_FechaCreacion`,`CON_MotivoTransaccion_Fechamodificacion`) VALUES (1,'A','Compra A Credito',Now(),Now());
INSERT INTO `CON_MotivoTransaccion` (`CON_MotivoTransaccion_ID`,`CON_MotivoTransaccion_Codigo`,`CON_MotivoTransaccion_Descripcion`,`CON_MotivoTransaccion_FechaCreacion`,`CON_MotivoTransaccion_Fechamodificacion`) VALUES (2,'B','Venta',Now(),Now());
INSERT INTO `CON_MotivoTransaccion` (`CON_MotivoTransaccion_ID`,`CON_MotivoTransaccion_Codigo`,`CON_MotivoTransaccion_Descripcion`,`CON_MotivoTransaccion_FechaCreacion`,`CON_MotivoTransaccion_Fechamodificacion`) VALUES (3,'D','Pago',Now(),Now());
INSERT INTO `CON_MotivoTransaccion` (`CON_MotivoTransaccion_ID`,`CON_MotivoTransaccion_Codigo`,`CON_MotivoTransaccion_Descripcion`,`CON_MotivoTransaccion_FechaCreacion`,`CON_MotivoTransaccion_Fechamodificacion`) VALUES (4,'C','Entrada Inventario',Now(),Now());
INSERT INTO `CON_MotivoTransaccion` (`CON_MotivoTransaccion_ID`,`CON_MotivoTransaccion_Codigo`,`CON_MotivoTransaccion_Descripcion`,`CON_MotivoTransaccion_FechaCreacion`,`CON_MotivoTransaccion_Fechamodificacion`) VALUES (5,'E','Salida Inventario',Now(),Now());
INSERT INTO `CON_MotivoTransaccion` (`CON_MotivoTransaccion_ID`,`CON_MotivoTransaccion_Codigo`,`CON_MotivoTransaccion_Descripcion`,`CON_MotivoTransaccion_FechaCreacion`,`CON_MotivoTransaccion_Fechamodificacion`) VALUES (6,'F','Devolucion',Now(),Now());
