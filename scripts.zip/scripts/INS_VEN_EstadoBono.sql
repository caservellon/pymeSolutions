/*
-- Query: 
-- Date: 2014-02-17 19:41
*/
INSERT INTO `VEN_EstadoBono` (`VEN_EstadoBono_id`,`VEN_EstadoBono_Codigo`,`VEN_EstadoBono_Nombre`,`VEN_EstadoBono_Descripcion`) VALUES (1,'VIG','Vigente','El bono esta vigente');
INSERT INTO `VEN_EstadoBono` (`VEN_EstadoBono_id`,`VEN_EstadoBono_Codigo`,`VEN_EstadoBono_Nombre`,`VEN_EstadoBono_Descripcion`) VALUES (2,'VEN','Vencido','El bono esta vencido');
INSERT INTO `VEN_EstadoBono` (`VEN_EstadoBono_id`,`VEN_EstadoBono_Codigo`,`VEN_EstadoBono_Nombre`,`VEN_EstadoBono_Descripcion`) VALUES (3,'CAN','Canjeado','El bono esta canjeado');
