/*
-- Query: 
-- Date: 2014-02-27 18:31
*/
INSERT INTO `CON_ClasificacionCuenta` (`CON_ClasificacionCuenta_ID`,`CON_ClasificacionCuenta_Codigo`,`CON_ClasificacionCuenta_Nombre`,`CON_ClasificacionCuenta_FechaCreacion`,`CON_ClasificacionCuenta_FechaModificacion`) VALUES (1,'11','Activo Corriente','03-03-03',Now());
INSERT INTO `CON_ClasificacionCuenta` (`CON_ClasificacionCuenta_ID`,`CON_ClasificacionCuenta_Codigo`,`CON_ClasificacionCuenta_Nombre`,`CON_ClasificacionCuenta_FechaCreacion`,`CON_ClasificacionCuenta_FechaModificacion`) VALUES (2,'121','Propiedad Planta y Equipo','03-03-03',Now());
INSERT INTO `CON_ClasificacionCuenta` (`CON_ClasificacionCuenta_ID`,`CON_ClasificacionCuenta_Codigo`,`CON_ClasificacionCuenta_Nombre`,`CON_ClasificacionCuenta_FechaCreacion`,`CON_ClasificacionCuenta_FechaModificacion`) VALUES (3,'122','Activos Intangibles','03-03-03',Now());
INSERT INTO `CON_ClasificacionCuenta` (`CON_ClasificacionCuenta_ID`,`CON_ClasificacionCuenta_Codigo`,`CON_ClasificacionCuenta_Nombre`,`CON_ClasificacionCuenta_FechaCreacion`,`CON_ClasificacionCuenta_FechaModificacion`) VALUES (4,'21','Pasivos Corrientes','03-03-03',Now());
INSERT INTO `CON_ClasificacionCuenta` (`CON_ClasificacionCuenta_ID`,`CON_ClasificacionCuenta_Codigo`,`CON_ClasificacionCuenta_Nombre`,`CON_ClasificacionCuenta_FechaCreacion`,`CON_ClasificacionCuenta_FechaModificacion`) VALUES (5,'22','Pasivos no Corrientes','03-03-03',Now());
INSERT INTO `CON_ClasificacionCuenta` (`CON_ClasificacionCuenta_ID`,`CON_ClasificacionCuenta_Codigo`,`CON_ClasificacionCuenta_Nombre`,`CON_ClasificacionCuenta_FechaCreacion`,`CON_ClasificacionCuenta_FechaModificacion`) VALUES (6,'31','Capital Contable/Patrimonio: Comerciante Individual','03-03-03',Now());
INSERT INTO `CON_ClasificacionCuenta` (`CON_ClasificacionCuenta_ID`,`CON_ClasificacionCuenta_Codigo`,`CON_ClasificacionCuenta_Nombre`,`CON_ClasificacionCuenta_FechaCreacion`,`CON_ClasificacionCuenta_FechaModificacion`) VALUES (7,'32','Capital Contable/Patrimonio: Empresa Jurídica','03-03-03',Now());
INSERT INTO `CON_ClasificacionCuenta` (`CON_ClasificacionCuenta_ID`,`CON_ClasificacionCuenta_Codigo`,`CON_ClasificacionCuenta_Nombre`,`CON_ClasificacionCuenta_FechaCreacion`,`CON_ClasificacionCuenta_FechaModificacion`) VALUES (8,'4','Ingresos','03-03-03',Now());
INSERT INTO `CON_ClasificacionCuenta` (`CON_ClasificacionCuenta_ID`,`CON_ClasificacionCuenta_Codigo`,`CON_ClasificacionCuenta_Nombre`,`CON_ClasificacionCuenta_FechaCreacion`,`CON_ClasificacionCuenta_FechaModificacion`) VALUES (9,'5','Gastos','03-03-03',Now());
