/*
-- Query: 
-- Date: 2014-02-17 19:33
*/
INSERT INTO `VEN_FormaPago` (`VEN_FormaPago_id`,`VEN_FormaPago_Descripcion`, `VEN_FormaPago_Codigo`) VALUES (1,'Tarjeta de Credito', 'TDC');
INSERT INTO `VEN_FormaPago` (`VEN_FormaPago_id`,`VEN_FormaPago_Descripcion`, `VEN_FormaPago_Codigo`) VALUES (2,'Efectivo', 'EFC');
INSERT INTO `VEN_FormaPago` (`VEN_FormaPago_id`,`VEN_FormaPago_Descripcion`, `VEN_FormaPago_Codigo`) VALUES (3,'Cheques', 'CHE');
INSERT INTO `VEN_FormaPago` (`VEN_FormaPago_id`,`VEN_FormaPago_Descripcion`, `VEN_FormaPago_Codigo`) VALUES (4,'Bono de Compra', 'BON');
INSERT INTO `VEN_FormaPago` (`VEN_FormaPago_id`,`VEN_FormaPago_Descripcion`, `VEN_FormaPago_Codigo`) VALUES (5,'Transferencia ACH', 'ACH');
INSERT INTO `VEN_FormaPago` (`VEN_FormaPago_id`,`VEN_FormaPago_Descripcion`, `VEN_FormaPago_Codigo`) VALUES (6,'Transferencia TEF', 'TEF');
INSERT INTO `VEN_FormaPago` (`VEN_FormaPago_id`,`VEN_FormaPago_Descripcion`, `VEN_FormaPago_Codigo`) VALUES (7,'Pago al Credito', 'PAC');
