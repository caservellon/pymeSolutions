/*
-- Query: 
-- Date: 2014-03-15 00:16
*/
INSERT INTO `CRM_TipoDocumento` (`CRM_TipoDocumento_ID`,`CRM_TipoDocumento_Codigo`,`CRM_TipoDocumento_Nombre`,`CRM_TipoDocumento_Validacion`) VALUES (1,'ID','Identidad Hondureña','####-####-#####');
INSERT INTO `CRM_TipoDocumento` (`CRM_TipoDocumento_ID`,`CRM_TipoDocumento_Codigo`,`CRM_TipoDocumento_Nombre`,`CRM_TipoDocumento_Validacion`) VALUES (2,'RTN','Registro Tributario Nacional','####-####-######');
INSERT INTO `CRM_TipoDocumento` (`CRM_TipoDocumento_ID`,`CRM_TipoDocumento_Codigo`,`CRM_TipoDocumento_Nombre`,`CRM_TipoDocumento_Validacion`) VALUES (3,'PASS','Pasaporte Gringo','####/#####');
INSERT INTO `CRM_TipoDocumento` (`CRM_TipoDocumento_ID`,`CRM_TipoDocumento_Codigo`,`CRM_TipoDocumento_Nombre`,`CRM_TipoDocumento_Validacion`) VALUES (4,'SSN','Numero de Seguridad Social','###-##-####');
