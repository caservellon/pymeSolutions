/*
-- Query: 
-- Date: 2014-02-17 08:44
*/
INSERT INTO `VEN_PeriodoCierreDeCaja` (`VEN_PeriodoCierreDeCaja_id`,`VEN_PeriodoCierreDeCaja_Codigo`,`VEN_PeriodoCierreDeCaja_ValorHoras`,`VEN_PeriodoCierreDeCaja_Estado`,`VEN_PeriodoCierreDeCaja_HoraPartida`) VALUES (1,'CC1','36','1','7:00');
INSERT INTO `VEN_PeriodoCierreDeCaja` (`VEN_PeriodoCierreDeCaja_id`,`VEN_PeriodoCierreDeCaja_Codigo`,`VEN_PeriodoCierreDeCaja_ValorHoras`,`VEN_PeriodoCierreDeCaja_Estado`,`VEN_PeriodoCierreDeCaja_HoraPartida`) VALUES (2,'CC2','48','1','20:30');
INSERT INTO `VEN_PeriodoCierreDeCaja` (`VEN_PeriodoCierreDeCaja_id`,`VEN_PeriodoCierreDeCaja_Codigo`,`VEN_PeriodoCierreDeCaja_ValorHoras`,`VEN_PeriodoCierreDeCaja_Estado`,`VEN_PeriodoCierreDeCaja_HoraPartida`) VALUES (3,'CC3','96','0','8:00');
