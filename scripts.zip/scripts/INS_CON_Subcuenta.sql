/*
-- Query: 
-- Date: 2014-02-27 20:34
*/
INSERT INTO `CON_Subcuenta` (`CON_Subcuenta_ID`,`CON_Subcuenta_Codigo`,`CON_Subcuenta_Nombre`,`CON_Subcuenta_FechaCreacion`,`CON_Subcuenta_FechaModificacion`,`CON_CatalogoContable_ID`) VALUES (1,'1','Caja',Now(),Now(),1);
INSERT INTO `CON_Subcuenta` (`CON_Subcuenta_ID`,`CON_Subcuenta_Codigo`,`CON_Subcuenta_Nombre`,`CON_Subcuenta_FechaCreacion`,`CON_Subcuenta_FechaModificacion`,`CON_CatalogoContable_ID`) VALUES (2,'2','Banco Ficohsa',Now(),Now(),1);
INSERT INTO `CON_Subcuenta` (`CON_Subcuenta_ID`,`CON_Subcuenta_Codigo`,`CON_Subcuenta_Nombre`,`CON_Subcuenta_FechaCreacion`,`CON_Subcuenta_FechaModificacion`,`CON_CatalogoContable_ID`) VALUES (3,'3','Banco CityBank',Now(),Now(),1);
INSERT INTO `CON_Subcuenta` (`CON_Subcuenta_ID`,`CON_Subcuenta_Codigo`,`CON_Subcuenta_Nombre`,`CON_Subcuenta_FechaCreacion`,`CON_Subcuenta_FechaModificacion`,`CON_CatalogoContable_ID`) VALUES (4,'4','Banco Atlantida',Now(),Now(),1);
INSERT INTO `CON_Subcuenta` (`CON_Subcuenta_ID`,`CON_Subcuenta_Codigo`,`CON_Subcuenta_Nombre`,`CON_Subcuenta_FechaCreacion`,`CON_Subcuenta_FechaModificacion`,`CON_CatalogoContable_ID`) VALUES (5,'1','SANAA',Now(),Now(),37);
INSERT INTO `CON_Subcuenta` (`CON_Subcuenta_ID`,`CON_Subcuenta_Codigo`,`CON_Subcuenta_Nombre`,`CON_Subcuenta_FechaCreacion`,`CON_Subcuenta_FechaModificacion`,`CON_CatalogoContable_ID`) VALUES (6,'2','ENEE',Now(),Now(),37);
INSERT INTO `CON_Subcuenta` (`CON_Subcuenta_ID`,`CON_Subcuenta_Codigo`,`CON_Subcuenta_Nombre`,`CON_Subcuenta_FechaCreacion`,`CON_Subcuenta_FechaModificacion`,`CON_CatalogoContable_ID`) VALUES (7,'3','HONDUTEL',Now(),Now(),37);
INSERT INTO `CON_Subcuenta` (`CON_Subcuenta_ID`,`CON_Subcuenta_Codigo`,`CON_Subcuenta_Nombre`,`CON_Subcuenta_FechaCreacion`,`CON_Subcuenta_FechaModificacion`,`CON_CatalogoContable_ID`) VALUES (8,'1','Inventario en Transito',Now(),Now(),5);
