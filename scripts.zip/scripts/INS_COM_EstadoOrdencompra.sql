
INSERT INTO `COM_EstadoOrdenCompra` (`COM_EstadoOrdenCompra_IdEstadoOrdenCompra`,`COM_EstadoOrdenCompra_Codigo`,`COM_EstadoOrdenCompra_Nombre`,`COM_EstadoOrdenCompra_Observacion`,`COM_EstadoOrdenCompra_Activo`) VALUES (1,'COM_EOC000000001','Cancelada','La orden fue cancelada',0);
INSERT INTO `COM_EstadoOrdenCompra` (`COM_EstadoOrdenCompra_IdEstadoOrdenCompra`,`COM_EstadoOrdenCompra_Codigo`,`COM_EstadoOrdenCompra_Nombre`,`COM_EstadoOrdenCompra_Observacion`,`COM_EstadoOrdenCompra_Activo`) VALUES (2,'COM_EOC000000002','En Espera de Autorizacion','La orden esta esperando ser autorizada',0);
INSERT INTO `COM_EstadoOrdenCompra` (`COM_EstadoOrdenCompra_IdEstadoOrdenCompra`,`COM_EstadoOrdenCompra_Codigo`,`COM_EstadoOrdenCompra_Nombre`,`COM_EstadoOrdenCompra_Observacion`,`COM_EstadoOrdenCompra_Activo`) VALUES (3,'COM_EOC000000003','Autorizada','La orden fue autorizada',0);
INSERT INTO `COM_EstadoOrdenCompra` (`COM_EstadoOrdenCompra_IdEstadoOrdenCompra`,`COM_EstadoOrdenCompra_Codigo`,`COM_EstadoOrdenCompra_Nombre`,`COM_EstadoOrdenCompra_Observacion`,`COM_EstadoOrdenCompra_Activo`) VALUES (4,'COM_EOC000000004','Emitida','La orden fue enviada a su proveedor',0);
INSERT INTO `COM_EstadoOrdenCompra` (`COM_EstadoOrdenCompra_IdEstadoOrdenCompra`,`COM_EstadoOrdenCompra_Codigo`,`COM_EstadoOrdenCompra_Nombre`,`COM_EstadoOrdenCompra_Observacion`,`COM_EstadoOrdenCompra_Activo`) VALUES (5,'COM_EOC000000005','Recibida','La orden fue recibida',0);


